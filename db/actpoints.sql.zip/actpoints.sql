-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 15, 2015 at 01:50 PM
-- Server version: 5.5.44-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mcaapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `actpoints`
--

CREATE TABLE IF NOT EXISTS `actpoints` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `actpoints`
--

INSERT INTO `actpoints` (`id`, `title`, `created_at`, `updated_at`) VALUES
(2, 'Dolor in in in aut in ex accusamus porro ipsa libero officia odio velit veniam eaque harum ad', '2015-10-12 00:57:37', '2015-10-12 00:57:37'),
(3, 'Quis rem accusamus ea non atque est vel incidunt quibusdam natus nulla minima', '2015-10-12 00:57:42', '2015-10-12 00:57:42'),
(4, 'Qui non non voluptatibus dolor ullam commodo distinctio Repellendus Sequi dolorum explicabo Sit tempora tempora facere voluptas corrupti veniam eiusmod', '2015-10-12 01:47:36', '2015-10-12 01:47:36');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
