-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 02, 2015 at 11:05 AM
-- Server version: 5.5.43-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `iucms`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'The Developer', 'bazlur.rashid@dnet.org.bd', '$2y$10$/Ya3OwGnkdHtd6MairoNROZwxTkcFrEqJv7CpW1YntefDtmuzVT8G', '', '2015-05-20 05:00:30', '2015-06-01 02:54:18'),
(2, 'Sattajit', 'sattyajit.sarker@dnet.org.bd', '$2y$10$7BZ5hF1JeFi7PKArJoz9zeIyb8stCLoJBkkwnMRPbamT8lcpPZ332', NULL, '2015-05-20 06:23:03', '2015-05-20 06:23:03'),
(3, 'The Site Admin', 'sakib.sharif@dnet.org.bd', '$2y$10$/Ya3OwGnkdHtd6MairoNROZwxTkcFrEqJv7CpW1YntefDtmuzVT8G', '', '2015-05-24 04:40:57', '2015-05-24 04:48:23'),
(4, 'MCA', 'assdfsdfsd@aaa.com', '$2y$10$ayD00VUbERm6fA6RZ1WNpun1Tcm5gorA0IXw6rbGOfTQc0Vj/iANq', NULL, '2015-06-01 04:20:53', '2015-06-01 04:20:53'),
(5, 'bazlur', 'mailtobazlur5@gmail.com', '$2y$10$kyeuwryATFSBwdLAMgmII.ty7oDpXGJkY3GSSfVC4808NecOi4iZK', NULL, '2015-06-01 22:31:29', '2015-06-01 22:31:29'),
(6, 'sdfsd', 'mailtobazlur24@gmail.com', '$2y$10$Q6tgeI6vopK8dV.xmJ.6Heavxif7Z/imH3MNCaVXcC2E6yTdndRt.', NULL, '2015-06-01 23:02:24', '2015-06-01 23:02:24');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
