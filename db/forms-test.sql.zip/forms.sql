-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 24, 2015 at 12:40 PM
-- Server version: 5.5.46-0ubuntu0.14.04.2
-- PHP Version: 5.5.9-1ubuntu4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mcaapp_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `forms`
--

CREATE TABLE IF NOT EXISTS `forms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=27 ;

--
-- Dumping data for table `forms`
--

INSERT INTO `forms` (`id`, `task_id`, `title`, `created_at`, `updated_at`, `order`) VALUES
(1, 10, 'NGO BD apply for Repatriation to MoHA', '2015-09-27 08:31:07', '2015-09-27 08:31:07', 10),
(3, 10, 'Nationality Identification', '2015-09-27 08:53:16', '2015-11-18 02:50:05', 20),
(11, 11, 'Request for FRRO Clearance from BDHC/ NGO IN to Home F&NRI/ I Branch', '2015-09-27 09:03:52', '2015-11-18 03:06:30', 10),
(12, 11, 'Request for NOC Letter from F&NRI to IG IB', '2015-09-27 09:04:13', '2015-11-18 03:08:38', 20),
(13, 11, 'Request for NOC Letter from Home F&NRI/ I Branch or IG IB to DIB/ Local Police', '2015-09-27 09:07:15', '2015-11-18 03:09:00', 30),
(14, 11, 'Request for NOC from NGO IN to DWCD/ MHA Maharashtra', '2015-09-27 09:07:41', '2015-11-18 03:10:03', 50),
(15, 11, 'DIB/ Local Police Send NOC to Home F&NRI/ I Branch', '2015-09-27 09:08:17', '2015-11-18 03:09:22', 40),
(16, 13, 'MoHA Issue and Send Repatriation Order to MoFA', '2015-09-27 09:09:27', '2015-11-18 03:15:56', 10),
(17, 13, 'NGO BD forward Repatriation Order to NGO IN', '2015-09-27 09:09:42', '2015-11-18 03:16:07', 20),
(18, 13, 'NGO IN forward RO to BDHC, CWC/ Magistrate Court', '2015-09-27 09:10:00', '2015-11-18 03:16:36', 30),
(20, 15, 'Fixation of Repatriation Date', '2015-09-27 09:11:27', '2015-11-18 03:19:12', 10),
(21, 15, 'Survivor Handover', '2015-09-27 09:11:40', '2015-11-18 00:08:58', 20),
(22, 16, 'Home F&NRI/ I Branch Issue and Send Repatriation Letter to DIB/ NGO IN', '2015-11-03 22:17:47', '2015-11-18 03:17:27', 10),
(23, 17, 'BDHC Issue Travel Permit', '2015-11-17 05:53:23', '2015-11-17 05:59:08', 10),
(24, 10, 'MoHA sends State HIR request to SBHQ', '2015-11-18 02:34:21', '2015-11-18 02:34:21', 15),
(25, 11, 'MHA Maharashtra Issue and Send NOC to NGO IN', '2015-11-18 03:10:40', '2015-11-18 03:10:40', 60),
(26, 16, 'NGO IN Forward Repatriation Letter to NGO BD', '2015-11-18 03:17:46', '2015-11-18 03:17:46', 20);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
