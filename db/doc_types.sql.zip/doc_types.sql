-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 21, 2016 at 04:45 PM
-- Server version: 5.5.46-0ubuntu0.14.04.2
-- PHP Version: 5.5.9-1ubuntu4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mcaapp_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `doc_types`
--

CREATE TABLE IF NOT EXISTS `doc_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `doc_types`
--

INSERT INTO `doc_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Victim Personal Image', '2015-09-16 23:49:48', '2015-09-16 23:49:48'),
(2, 'Victim Child Personal Image', '2015-09-17 04:15:27', '2015-09-17 04:15:27'),
(3, 'National ID', '2015-12-16 22:52:33', '2015-12-16 22:52:33'),
(4, 'Birth Cetrtificate', '2015-12-16 22:52:41', '2015-12-16 22:52:41'),
(5, 'Citizenship Certificate', '2015-12-16 22:52:50', '2015-12-16 22:52:50'),
(7, 'Passport', '2015-12-16 22:53:12', '2015-12-16 22:53:12'),
(8, 'Case Release Document (CRD)', '2015-12-16 22:53:12', '2015-12-16 22:53:12'),
(9, 'Court Order', '2015-12-16 22:53:12', '2015-12-16 22:53:12'),
(10, 'Other', '2015-12-16 22:53:12', '2015-12-16 22:53:12');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
