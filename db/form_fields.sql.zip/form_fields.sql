-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 12, 2016 at 11:31 AM
-- Server version: 5.5.53-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `old_mcaaap`
--

-- --------------------------------------------------------

--
-- Table structure for table `form_fields`
--

CREATE TABLE IF NOT EXISTS `form_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `form_id` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=24 ;

--
-- Dumping data for table `form_fields`
--

INSERT INTO `form_fields` (`id`, `title`, `type`, `form_id`, `order`, `created_at`, `updated_at`) VALUES
(7, 'Date of Fixation', 'date', 32, 10, '2016-07-12 03:46:43', '2016-07-12 04:57:53'),
(8, 'Date of Repatriation', 'date', 32, 20, '2016-07-12 04:41:16', '2016-07-13 00:33:01'),
(9, 'Date of Handover', 'date', 33, 0, '2016-07-12 04:50:35', '2016-07-12 04:50:35'),
(10, 'List of Document and belongings handed over to NGO NP by NGO IN', 'rte', 33, 10, '2016-07-12 04:50:58', '2016-07-12 04:57:42'),
(11, 'List of actors particpating during handover (India Side) (Name, Designation, Organization)', 'rte', 33, 20, '2016-07-12 04:53:46', '2016-07-12 04:57:42'),
(12, 'List of actors particating during handover (Nepal Side) (Name, Designation, Organization)', 'rte', 33, 30, '2016-07-12 04:54:03', '2016-07-12 04:57:43'),
(13, 'Date of Submission', 'date', 34, 0, '2016-07-13 03:27:21', '2016-07-13 03:27:21'),
(14, 'Date of Issue', 'date', 35, 0, '2016-07-13 03:43:31', '2016-07-13 03:43:31'),
(15, 'Date of Receiving by NGO India', 'date', 35, 0, '2016-07-13 03:44:03', '2016-07-13 03:44:03'),
(16, 'Date of Action', 'date', 36, 0, '2016-07-13 03:44:30', '2016-07-13 03:44:30'),
(17, 'Issuer', 'text', 37, 0, '2016-11-07 22:30:36', '2016-11-08 00:20:49'),
(18, 'Issued to', 'text', 37, 0, '2016-11-07 22:32:16', '2016-11-08 00:20:44'),
(19, 'Issuer Organization', 'text', 37, 0, '2016-11-07 22:35:32', '2016-11-08 00:20:39'),
(20, 'Issued to Organization', 'text', 37, 0, '2016-11-07 22:35:53', '2016-11-08 00:20:34'),
(21, 'Issue Date', 'date', 37, 0, '2016-11-07 23:01:16', '2016-11-07 23:01:16'),
(22, 'Approval Date', 'date', 37, 0, '2016-11-07 23:15:24', '2016-11-08 00:14:04'),
(23, 'Vacancy Letter Status', 'text', 37, 0, '2016-11-07 23:57:42', '2016-11-07 23:57:42');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
