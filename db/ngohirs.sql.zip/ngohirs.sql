--
-- Database: `mcaapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `ngohirs`
--

CREATE TABLE `ngohirs` (
  `id` int(10) UNSIGNED NOT NULL,
  `litigation_id` int(11) DEFAULT NULL,
  `name_of_interviewer` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `place_of_interview` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_of_interview` date DEFAULT NULL,
  `name_of_informer` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_of_the_survivor_at_source` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_of_the_survivor_at_destination` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `father_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mother_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marital_status` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `spouse_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `nationality` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `religion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `education` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `history_of_previous_stay` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `height_ft_part` int(11) DEFAULT NULL,
  `height_in_part` int(11) DEFAULT NULL,
  `sex` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birth_mark` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `complexion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pregnancy` int(11) DEFAULT NULL,
  `accompanying_with_survivor` int(11) DEFAULT NULL,
  `abuse` int(11) DEFAULT NULL,
  `if_yes_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ngohirs`
--

INSERT INTO `ngohirs` (`id`, `litigation_id`, `name_of_interviewer`, `place_of_interview`, `date_of_interview`, `name_of_informer`, `name_of_the_survivor_at_source`, `name_of_the_survivor_at_destination`, `father_name`, `mother_name`, `marital_status`, `spouse_name`, `date_of_birth`, `nationality`, `religion`, `education`, `history_of_previous_stay`, `height_ft_part`, `height_in_part`, `sex`, `birth_mark`, `complexion`, `pregnancy`, `accompanying_with_survivor`, `abuse`, `if_yes_type`, `created_at`, `updated_at`) VALUES
(1, 32, 'Shaon', 'dhaka', '0000-00-00', 'no one', 'bilkis', 'bilkis story', 'f. name', 'm. name', 'S', 's. name', '0000-00-00', '1', 'muslim', '5 pass', '<p>This is</p>\r\n\r\n<p>a</p>\r\n\r\n<p>test&nbsp;</p>\r\n\r\n<p>history.</p>\r\n', 4, 1, 'F', 'black spot', 'none', 0, 1, 1, 'don''t know', '2015-09-23 00:11:42', '2015-09-23 00:11:42'),
(2, 32, 'Gemma Conrad', 'In sint dolore ab in omnis aut fuga A et veniam minima delectus saepe tenetur', '2015-09-04', 'Jelani Miles', 'Rosalyn Burch', 'Ethan Allison', 'Shad Lawrence', 'Grady Patton', 'W', 'Beck Byers', '1996-05-30', '2', 'Ut laborum ipsam omnis architecto voluptate maiores aut nisi reiciendis', 'Excepturi eos sequi dolorum rem corrupti sint et qui dolor quis aperiam excepteur et quia quis dolores temporibus quisquam', '<p>cvadvdvsd</p>\r\n\r\n<p>vs</p>\r\n\r\n<p>dv</p>\r\n\r\n<p>sdv</p>\r\n\r\n<p>sd</p>\r\n\r\n<p>vs</p>\r\n\r\n<p>dvsdvsd &nbsp;asdvwdvsdavasdv</p>\r\n', 3, 5, 'F', 'Deleniti aperiam laboriosam necessitatibus exercitationem', 'Qui vel Nam voluptate consequat Aute ut enim', 1, NULL, 0, 'Et perferendis officia reprehenderit natus tempore exercitation quo ipsum labore perferendis velit ipsa mollitia nesciunt quo quia aspernatur laborum cumque', '2015-09-23 00:31:11', '2015-09-23 00:31:11'),
(3, 10, 'Brandon Lopez', 'Neque reiciendis nulla laborum Culpa', '2015-09-23', 'Montana Shields', 'Vielka Gill', 'Tamekah Franco', 'Lani Ward', 'Conan Stewart', 'D', 'Madonna Burton', '2015-09-23', '2', 'Ut eiusmod pariatur Esse in ut eu enim sunt excepturi esse assumenda', 'Modi cupidatat impedit rem occaecat tenetur eu exercitationem officia eos et lorem consequatur', 'Voluptatem repellendus. Culpa esse, adipisicing minus voluptas ad do voluptatem, vero porro fugit.\r\n\r\nca\r\nca\r\nca\r\n\r\nac\r\nasc', 2, 9, 'F', 'Veritatis eum atque in mollitia ut earum exercitation sit', 'Eveniet dolor dicta ut obcaecati illo velit voluptate qui eu vel ducimus sed iure exercitation', 1, NULL, 0, 'Alias quibusdam corrupti nemo sint dolore reiciendis qui ducimus nesciunt voluptates', '2015-09-23 04:28:53', '2015-09-23 04:28:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ngohirs`
--
ALTER TABLE `ngohirs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ngohirs`
--
ALTER TABLE `ngohirs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
