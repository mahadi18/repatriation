-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 12, 2016 at 12:03 PM
-- Server version: 5.5.53-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `old_mcaaap`
--

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE IF NOT EXISTS `tasks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `order` int(255) NOT NULL DEFAULT '1000',
  `countries` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `title`, `parent_id`, `order`, `countries`, `created_at`, `updated_at`) VALUES
(1, 'Case Details', 0, 1, '2', '2015-09-03 06:39:12', '2015-11-18 22:58:17'),
(2, 'Intake Part A - Rescue Story', 1, 2, '2', '2015-09-03 06:39:12', '2015-11-18 22:58:28'),
(3, 'Judicial Proceeding', 1, 5, '2', '2015-09-03 06:39:12', '2015-09-03 08:36:56'),
(4, 'Intake Part B - Personal Information', 1, 3, '2', '2015-09-03 06:39:12', '2015-11-18 22:58:43'),
(5, 'Location Log', 1, 6, '2', '2015-09-03 06:39:12', '2015-11-18 22:59:11'),
(6, 'Case Story', 1, 4, '2', '2015-09-03 06:39:12', '2015-11-18 22:58:51'),
(7, 'Care Plan', 1, 7, '2', '2015-09-03 06:39:12', '2015-09-03 08:42:18'),
(9, 'NGO HIR', 0, 9, '1,2,3', '2015-09-03 06:39:12', '2015-11-16 23:15:42'),
(10, 'State HIR', 0, 10, '1,2,3', '2015-09-03 06:39:12', '2015-11-16 23:32:03'),
(11, 'NOC and FRRO Clearance', 0, 13, '2', '2015-09-03 06:39:12', '2015-09-27 09:03:34'),
(13, 'Repatriation Order from Source', 0, 11, '1,2,3', '2015-09-03 06:39:12', '2015-11-22 03:02:47'),
(15, 'Repatriation at Border', 0, 16, '1,2,3', '2015-09-03 09:09:50', '2015-11-16 23:35:10'),
(16, 'Repatriation Letter at Destination Country', 0, 13, '2', '2015-09-29 09:57:31', '2016-09-25 00:02:39'),
(17, 'Travel Permit', 0, 14, '2', '2015-11-17 05:42:16', '2015-11-17 05:58:37'),
(18, 'Vacancy Letter from Source Country', 0, 15, '2,3', '2016-11-07 03:46:57', '2016-11-07 03:47:06');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
