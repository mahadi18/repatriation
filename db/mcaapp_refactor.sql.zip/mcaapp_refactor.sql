-- phpMyAdmin SQL Dump
-- version 4.4.6.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 17, 2015 at 09:00 AM
-- Server version: 5.6.24
-- PHP Version: 5.5.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mcaapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE IF NOT EXISTS `activities` (
  `id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'act1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'act2', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `attachments`
--

CREATE TABLE IF NOT EXISTS `attachments` (
  `id` int(10) unsigned NOT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `content_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uploaded_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `doc_type_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_defined_doc_type_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `task_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `attachment_litigation`
--

CREATE TABLE IF NOT EXISTS `attachment_litigation` (
  `id` int(10) unsigned NOT NULL,
  `attachment_id` int(11) NOT NULL,
  `litigation_id` int(11) NOT NULL,
  `comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `care_plans`
--

CREATE TABLE IF NOT EXISTS `care_plans` (
  `id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `care_plan_litigation`
--

CREATE TABLE IF NOT EXISTS `care_plan_litigation` (
  `litigation_id` int(10) unsigned NOT NULL,
  `care_plan_id` int(10) unsigned NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `care_plan_shelter_home`
--

CREATE TABLE IF NOT EXISTS `care_plan_shelter_home` (
  `shelter_home_id` int(10) unsigned NOT NULL,
  `care_plan_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `case_profiles`
--

CREATE TABLE IF NOT EXISTS `case_profiles` (
  `id` int(10) unsigned NOT NULL,
  `litigation_id` int(11) NOT NULL,
  `activity_id` int(11) NOT NULL,
  `task_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `comments` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `doc_types`
--

CREATE TABLE IF NOT EXISTS `doc_types` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `litigations`
--

CREATE TABLE IF NOT EXISTS `litigations` (
  `id` int(10) unsigned NOT NULL,
  `victim_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `other_names` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `age` int(11) NOT NULL,
  `country_of_origin` int(255) NOT NULL,
  `destination_country` int(11) NOT NULL DEFAULT '2',
  `home_district` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rescue_place` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dob` date DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `religion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `spouse_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `father_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mother_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `shelter_home_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `litigations`
--

INSERT INTO `litigations` (`id`, `victim_name`, `other_names`, `alias`, `age`, `country_of_origin`, `destination_country`, `home_district`, `created_by`, `rescue_place`, `dob`, `gender`, `religion`, `spouse_name`, `father_name`, `mother_name`, `description`, `shelter_home_id`, `created_at`, `updated_at`) VALUES
(10, 'Orli Wilkinson hello', 'Keane Yates', 'Dolor libero sed voluptas et voluptatem Sit et officiis modi commodo', 87, 1, 2, 'Laboris doloremque sit non deserunt dolor cum deleniti incidunt nostrud quia minim irure culpa at distinctio', '1', 'Deserunt veniam id non lorem laborum libero minus beatae odit', '2015-07-23', 'Female', 'Officia nisi quasi doloribus neque velit explicabo Rerum consequuntur enim provident eveniet aliquam qui reprehenderit voluptatum nulla non labore eos', 'Miriam Kim', 'Holly Donaldson', 'Deborah Crawford', 'Hic occaecat accusamus quasi ut quae cupidatat qui occaecat ad.', '', '2015-07-23 12:01:19', '2015-08-13 06:18:55'),
(11, 'Eugenia Edwards', 'Ronan Fowler', 'Perferendis aut porro rerum molestiae saepe labore impedit voluptatem In sunt perspiciatis aut', 8, 3, 2, 'Eu qui id dolorum enim explicabo Atque error et quae commodi quis doloribus quis et', '1', 'Laborum voluptate sint et eum explicabo Ex officia libero fugiat quis doloribus et sit delectus nesciunt et ullamco', '2015-07-29', 'Male', 'Sint consequatur distinctio Amet quo et amet irure recusandae Eos fugiat laboris et dolor veniam qui', 'Rhona Flores', 'Cara Mcfarland', 'Germaine Soto', 'Eligendi harum quia eum mollit quos fugit, architecto quibusdam nihil distinctio. Alias totam neque voluptatum sunt sit, voluptatibus eos.', '', '2015-07-29 08:23:56', '2015-07-29 08:23:56'),
(12, 'Adria Skinner', 'Sebastian Steele', 'Obcaecati et laborum iure sed ea', 70, 0, 2, 'Iste sed aut similique voluptatem aliquip quis eiusmod', '1', 'Unde accusamus Nam ex iusto', '2015-07-29', 'Female', 'Soluta perferendis soluta blanditiis quidem omnis elit fuga Corrupti sit occaecat', 'Neve Knight', 'Glenna Boyer', 'Ebony Singleton', 'Ea quidem cupidatat debitis nostrud quia est velit, ex non ipsam distinctio. Odio fugit, tempor.', '', '2015-07-29 08:28:16', '2015-07-29 08:28:16'),
(26, 'Hoyt Olson', 'Hall Wynn', 'Cumque eaque nulla autem magna qui veniam inventore quos et adipisicing porro', 34, 2, 2, 'Aut corrupti adipisci dolor vero dolore adipisci dolore soluta', '1', 'Voluptatem veniam aut tempore eum nostrum aut fuga Vel sed', '2015-07-29', 'Female', 'Non nostrud iure culpa explicabo', 'Nayda Ashley', 'Cecilia Jones', 'Brielle Wiley', 'Eos libero mollit mollit corporis aut quia eiusmod aspernatur laudantium, velit ut aut sint itaque in sed cillum.', '', '2015-07-29 08:42:22', '2015-07-29 08:42:22'),
(27, 'Hoyt Olson', 'Hall Wynn', 'Cumque eaque nulla autem magna qui veniam inventore quos et adipisicing porro', 34, 1, 2, 'Aut corrupti adipisci dolor vero dolore adipisci dolore soluta', '1', 'Voluptatem veniam aut tempore eum nostrum aut fuga Vel sed', '2015-07-29', 'Female', 'Non nostrud iure culpa explicabo', 'Nayda Ashley', 'Cecilia Jones', 'Brielle Wiley', 'Eos libero mollit mollit corporis aut quia eiusmod aspernatur laudantium, velit ut aut sint itaque in sed cillum.', '', '2015-07-29 08:50:07', '2015-08-02 08:53:27'),
(28, 'Marny Mcclain', 'Jada Meadows', 'Dignissimos a dolores quibusdam vel', 3, 2, 2, 'Do veniam minus dolor numquam voluptate aut ad dolorem maxime consequatur', '1', 'Anim quis ut vitae obcaecati non ea earum voluptas et voluptatem qui voluptates rerum omnis vel mollitia asperiores rerum', '2015-08-02', 'Male', 'Non dicta aute sit nisi qui assumenda', 'Kai Villarreal', 'Gwendolyn Hopper', 'Harrison Huffman', 'Non non officia illum, dolor tenetur autem ea dolor alias voluptates temporibus ad at.', '', '2015-08-02 05:10:17', '2015-08-02 05:10:17');

-- --------------------------------------------------------

--
-- Table structure for table `litigation_organization`
--

CREATE TABLE IF NOT EXISTS `litigation_organization` (
  `litigation_id` int(10) unsigned NOT NULL,
  `organization_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `litigation_organization`
--

INSERT INTO `litigation_organization` (`litigation_id`, `organization_id`) VALUES
(26, 1),
(27, 2),
(28, 2),
(10, 3),
(26, 5),
(27, 5),
(26, 6);

-- --------------------------------------------------------

--
-- Table structure for table `litigation_task_task_status`
--

CREATE TABLE IF NOT EXISTS `litigation_task_task_status` (
  `litigation_id` int(10) unsigned NOT NULL,
  `task_id` int(10) unsigned NOT NULL,
  `task_status_id` int(10) unsigned NOT NULL,
  `updated_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `assigned_country` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `marked_viewed` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `message_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `litigation_task_task_status`
--

INSERT INTO `litigation_task_task_status` (`litigation_id`, `task_id`, `task_status_id`, `updated_by`, `assigned_country`, `marked_viewed`, `message_id`, `created_at`, `updated_at`) VALUES
(10, 2, 1, '1', '1', '', '0', '2015-08-04 08:32:25', '0000-00-00 00:00:00'),
(10, 3, 1, '1', '2', '', '0', '2015-08-04 08:43:36', '0000-00-00 00:00:00'),
(10, 4, 2, '1', '2', '', '0', '2015-08-04 08:32:12', '0000-00-00 00:00:00'),
(10, 5, 1, '1', '1', '', '0', '2015-08-04 06:04:46', '0000-00-00 00:00:00'),
(10, 6, 3, '1', '2', '', '0', '2015-08-04 08:46:22', '0000-00-00 00:00:00'),
(10, 7, 3, '1', '2', '', '0', '2015-08-04 08:46:01', '0000-00-00 00:00:00'),
(10, 8, 1, '1', '2', '', '0', '2015-08-04 06:12:04', '0000-00-00 00:00:00'),
(10, 9, 1, '1', '2', '', '0', '2015-08-04 06:12:14', '0000-00-00 00:00:00'),
(10, 10, 1, '1', '1', '', '0', '2015-08-04 06:12:20', '0000-00-00 00:00:00'),
(10, 11, 4, '1', '2', '', '0', '2015-08-04 09:23:54', '0000-00-00 00:00:00'),
(10, 12, 4, '1', '1', '', '0', '2015-08-04 08:45:10', '0000-00-00 00:00:00'),
(10, 13, 4, '1', '1', '', '0', '2015-08-04 08:43:12', '0000-00-00 00:00:00'),
(10, 14, 3, '1', '1', '', '0', '2015-08-04 08:35:42', '0000-00-00 00:00:00'),
(10, 15, 1, '1', '2', '', '0', '2015-08-04 06:13:44', '0000-00-00 00:00:00'),
(10, 16, 4, '1', '3', '', '0', '2015-08-04 08:35:47', '0000-00-00 00:00:00'),
(11, 2, 1, '1', '1', '', '0', '2015-08-04 06:24:14', '0000-00-00 00:00:00'),
(11, 2, 1, '1', '2', '', '0', '2015-08-04 06:24:14', '0000-00-00 00:00:00'),
(11, 3, 1, '1', '2', '', '0', '2015-08-04 06:24:17', '0000-00-00 00:00:00'),
(11, 4, 1, '1', '1', '', '0', '2015-08-04 06:24:19', '0000-00-00 00:00:00'),
(11, 5, 1, '1', '2', '', '0', '2015-08-04 06:24:29', '0000-00-00 00:00:00'),
(11, 6, 1, '1', '1', '', '0', '2015-08-04 06:24:35', '0000-00-00 00:00:00'),
(11, 7, 1, '1', '2', '', '0', '2015-08-04 06:24:40', '0000-00-00 00:00:00'),
(11, 8, 1, '1', '1', '', '0', '2015-08-04 06:24:47', '0000-00-00 00:00:00'),
(11, 9, 1, '1', '2', '', '0', '2015-08-04 06:24:53', '0000-00-00 00:00:00'),
(11, 10, 1, '1', '1', '', '0', '2015-08-04 06:25:05', '0000-00-00 00:00:00'),
(11, 10, 1, '1', '2', '', '0', '2015-08-04 06:25:05', '0000-00-00 00:00:00'),
(11, 11, 1, '1', '2', '', '0', '2015-08-04 06:25:17', '0000-00-00 00:00:00'),
(11, 12, 1, '1', '2', '', '0', '2015-08-04 06:25:28', '0000-00-00 00:00:00'),
(11, 13, 1, '1', '1', '', '0', '2015-08-04 06:25:39', '0000-00-00 00:00:00'),
(11, 14, 1, '1', '1', '', '0', '2015-08-04 06:25:49', '0000-00-00 00:00:00'),
(11, 14, 1, '1', '2', '', '0', '2015-08-04 06:25:49', '0000-00-00 00:00:00'),
(11, 15, 1, '1', '1', '', '0', '2015-08-04 06:26:00', '0000-00-00 00:00:00'),
(11, 15, 1, '1', '2', '', '0', '2015-08-04 06:26:00', '0000-00-00 00:00:00'),
(11, 16, 1, '1', '1', '', '0', '2015-08-04 06:26:05', '0000-00-00 00:00:00'),
(12, 2, 1, '1', '1', '', '0', '2015-08-04 06:22:17', '0000-00-00 00:00:00'),
(12, 2, 1, '1', '2', '', '0', '2015-08-04 06:22:17', '0000-00-00 00:00:00'),
(12, 3, 1, '1', '1', '', '0', '2015-08-04 06:22:25', '0000-00-00 00:00:00'),
(12, 3, 1, '1', '2', '', '0', '2015-08-04 06:22:25', '0000-00-00 00:00:00'),
(12, 4, 1, '1', '1', '', '0', '2015-08-04 06:22:28', '0000-00-00 00:00:00'),
(12, 4, 1, '1', '2', '', '0', '2015-08-04 06:22:28', '0000-00-00 00:00:00'),
(12, 5, 1, '1', '1', '', '0', '2015-08-04 06:22:32', '0000-00-00 00:00:00'),
(12, 5, 1, '1', '2', '', '0', '2015-08-04 06:22:32', '0000-00-00 00:00:00'),
(12, 6, 1, '1', '1', '', '0', '2015-08-04 06:22:37', '0000-00-00 00:00:00'),
(12, 6, 1, '1', '2', '', '0', '2015-08-04 06:22:37', '0000-00-00 00:00:00'),
(12, 7, 1, '1', '1', '', '0', '2015-08-04 06:22:45', '0000-00-00 00:00:00'),
(12, 7, 1, '1', '2', '', '0', '2015-08-04 06:22:45', '0000-00-00 00:00:00'),
(12, 8, 1, '1', '1', '', '0', '2015-08-04 06:22:55', '0000-00-00 00:00:00'),
(12, 8, 1, '1', '2', '', '0', '2015-08-04 06:22:55', '0000-00-00 00:00:00'),
(12, 9, 1, '1', '1', '', '0', '2015-08-04 06:23:02', '0000-00-00 00:00:00'),
(12, 9, 1, '1', '2', '', '0', '2015-08-04 06:23:02', '0000-00-00 00:00:00'),
(12, 10, 1, '1', '1', '', '0', '2015-08-04 06:23:07', '0000-00-00 00:00:00'),
(12, 10, 1, '1', '2', '', '0', '2015-08-04 06:23:07', '0000-00-00 00:00:00'),
(12, 11, 1, '1', '1', '', '0', '2015-08-04 06:23:30', '0000-00-00 00:00:00'),
(12, 11, 1, '1', '2', '', '0', '2015-08-04 06:23:30', '0000-00-00 00:00:00'),
(12, 12, 1, '1', '1', '', '0', '2015-08-04 06:23:36', '0000-00-00 00:00:00'),
(12, 12, 1, '1', '2', '', '0', '2015-08-04 06:23:36', '0000-00-00 00:00:00'),
(12, 13, 1, '1', '1', '', '0', '2015-08-04 06:23:43', '0000-00-00 00:00:00'),
(12, 13, 1, '1', '2', '', '0', '2015-08-04 06:23:43', '0000-00-00 00:00:00'),
(12, 14, 1, '1', '1', '', '0', '2015-08-04 06:24:05', '0000-00-00 00:00:00'),
(12, 14, 1, '1', '2', '', '0', '2015-08-04 06:24:05', '0000-00-00 00:00:00'),
(12, 15, 1, '1', '1', '', '0', '2015-08-04 06:23:56', '0000-00-00 00:00:00'),
(12, 15, 1, '1', '2', '', '0', '2015-08-04 06:23:56', '0000-00-00 00:00:00'),
(12, 16, 1, '1', '1', '', '0', '2015-08-04 06:23:49', '0000-00-00 00:00:00'),
(12, 16, 1, '1', '2', '', '0', '2015-08-04 06:23:49', '0000-00-00 00:00:00'),
(26, 2, 1, '1', '1', '', '0', '2015-07-29 12:21:41', '0000-00-00 00:00:00'),
(26, 2, 1, '1', '3', '', '0', '2015-07-29 12:21:41', '0000-00-00 00:00:00'),
(26, 3, 1, '1', '2', '', '0', '2015-08-04 06:02:26', '0000-00-00 00:00:00'),
(26, 4, 1, '1', '2', '', '0', '2015-08-04 06:02:32', '0000-00-00 00:00:00'),
(26, 5, 1, '1', '2', '', '0', '2015-08-04 06:02:37', '0000-00-00 00:00:00'),
(26, 6, 1, '1', '2', '', '0', '2015-08-04 06:02:44', '0000-00-00 00:00:00'),
(26, 7, 1, '1', '2', '', '0', '2015-08-04 06:02:52', '0000-00-00 00:00:00'),
(26, 8, 1, '1', '2', '', '0', '2015-08-04 06:03:32', '0000-00-00 00:00:00'),
(26, 9, 1, '1', '2', '', '0', '2015-08-04 06:02:58', '0000-00-00 00:00:00'),
(26, 10, 1, '1', '1', '', '0', '2015-08-04 06:03:09', '0000-00-00 00:00:00'),
(26, 11, 1, '1', '1', '', '0', '2015-08-04 06:03:42', '0000-00-00 00:00:00'),
(26, 11, 1, '1', '2', '', '0', '2015-08-04 06:03:43', '0000-00-00 00:00:00'),
(26, 16, 1, '1', '1', '', '0', '2015-08-04 06:03:54', '0000-00-00 00:00:00'),
(26, 16, 1, '1', '2', '', '0', '2015-08-04 06:03:54', '0000-00-00 00:00:00'),
(27, 2, 4, '7', '1', '', '0', '2015-08-04 08:48:41', '0000-00-00 00:00:00'),
(27, 2, 4, '7', '2', '', '0', '2015-08-04 08:48:41', '0000-00-00 00:00:00'),
(27, 3, 1, '1', '1', '', '0', '2015-08-02 12:23:16', '0000-00-00 00:00:00'),
(27, 4, 4, '1', '1', '', '0', '2015-08-02 12:23:18', '0000-00-00 00:00:00'),
(27, 5, 1, '1', '1', '', '0', '2015-07-29 08:50:07', '0000-00-00 00:00:00'),
(27, 6, 1, '1', '1', '', '0', '2015-07-29 08:50:07', '0000-00-00 00:00:00'),
(27, 7, 1, '1', '1', '', '0', '2015-07-29 08:50:07', '0000-00-00 00:00:00'),
(27, 8, 1, '1', '1', '', '0', '2015-07-29 08:50:07', '0000-00-00 00:00:00'),
(27, 9, 1, '1', '1', '', '0', '2015-07-29 08:50:08', '0000-00-00 00:00:00'),
(27, 10, 1, '1', '1', '', '0', '2015-07-29 08:50:08', '0000-00-00 00:00:00'),
(27, 11, 1, '1', '1', '', '0', '2015-07-29 08:50:08', '0000-00-00 00:00:00'),
(27, 12, 1, '1', '1', '', '0', '2015-07-29 08:50:08', '0000-00-00 00:00:00'),
(27, 13, 1, '1', '1', '', '0', '2015-07-29 08:50:08', '0000-00-00 00:00:00'),
(27, 14, 1, '1', '1', '', '0', '2015-07-29 08:50:08', '0000-00-00 00:00:00'),
(27, 15, 1, '1', '1', '', '0', '2015-07-29 08:50:08', '0000-00-00 00:00:00'),
(27, 16, 3, '7', '2', '', '0', '2015-08-04 08:48:43', '0000-00-00 00:00:00'),
(28, 2, 1, '1', '1', '', '0', '2015-08-02 05:52:36', '0000-00-00 00:00:00'),
(28, 2, 1, '1', '2', '', '0', '2015-08-02 05:52:36', '0000-00-00 00:00:00'),
(28, 2, 1, '1', '3', '', '0', '2015-08-02 05:52:36', '0000-00-00 00:00:00'),
(28, 3, 1, '1', '1', '', '0', '2015-08-02 05:10:17', '0000-00-00 00:00:00'),
(28, 4, 1, '1', '1', '', '0', '2015-08-02 05:10:17', '0000-00-00 00:00:00'),
(28, 5, 1, '1', '1', '', '0', '2015-08-02 05:10:17', '0000-00-00 00:00:00'),
(28, 6, 1, '1', '1', '', '0', '2015-08-02 05:10:17', '0000-00-00 00:00:00'),
(28, 7, 1, '1', '1', '', '0', '2015-08-02 05:10:17', '0000-00-00 00:00:00'),
(28, 8, 1, '1', '1', '', '0', '2015-08-02 05:10:17', '0000-00-00 00:00:00'),
(28, 9, 1, '1', '1', '', '0', '2015-08-02 05:10:17', '0000-00-00 00:00:00'),
(28, 10, 1, '1', '1', '', '0', '2015-08-02 05:10:18', '0000-00-00 00:00:00'),
(28, 11, 1, '1', '1', '', '0', '2015-08-02 05:10:18', '0000-00-00 00:00:00'),
(28, 12, 1, '1', '1', '', '0', '2015-08-02 05:10:18', '0000-00-00 00:00:00'),
(28, 13, 1, '1', '1', '', '0', '2015-08-02 05:10:18', '0000-00-00 00:00:00'),
(28, 14, 1, '1', '1', '', '0', '2015-08-02 05:10:18', '0000-00-00 00:00:00'),
(28, 15, 1, '1', '1', '', '0', '2015-08-02 05:10:18', '0000-00-00 00:00:00'),
(28, 16, 1, '1', '1', '', '0', '2015-08-02 05:10:18', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(10) unsigned NOT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `sender` int(11) NOT NULL,
  `last_viewed_by` int(11) NOT NULL,
  `parent_message` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `subject`, `body`, `sender`, `last_viewed_by`, `parent_message`, `created_at`, `updated_at`) VALUES
(1, 'Non quibusdam consequatur neque vel.', '', 13, 0, 0, '2015-08-06 04:07:06', '2015-08-06 04:07:06'),
(2, 'Dicta error eligendi ex inventore.', '', 9, 0, 0, '2015-08-06 04:07:06', '2015-08-06 04:07:06'),
(3, 'Doloribus explicabo quas eius quos nostrum.', '', 12, 0, 0, '2015-08-06 04:07:06', '2015-08-06 04:07:06'),
(4, 'Ea quam non voluptatem quia voluptatem vel velit.', '', 5, 0, 0, '2015-08-06 04:07:06', '2015-08-06 04:07:06'),
(5, 'In dolorem neque et labore qui.', '', 13, 0, 0, '2015-08-06 04:07:06', '2015-08-06 04:07:06'),
(6, 'Sed incidunt sit aliquam aut.', '', 14, 0, 0, '2015-08-06 04:07:06', '2015-08-06 04:07:06'),
(7, 'Facere doloribus exercitationem quia corporis.', '', 1, 0, 0, '2015-08-06 04:07:06', '2015-08-06 04:07:06'),
(8, 'Nesciunt aliquid fugit et voluptas id hic.', '', 4, 0, 0, '2015-08-06 04:07:06', '2015-08-06 04:07:06'),
(9, 'Quidem perspiciatis hic pariatur non quidem in.', '', 3, 0, 0, '2015-08-06 04:07:06', '2015-08-06 04:07:06'),
(10, 'Veritatis dolores atque sit nihil ut et.', '', 13, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(11, 'Maiores laboriosam et deleniti et sapiente dolore.', '', 13, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(12, 'Dolores rem dignissimos autem fuga iste libero.', '', 12, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(13, 'Ipsum ut aliquam assumenda repudiandae minima laboriosam similique ipsam.', '', 14, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(14, 'Porro sunt sit optio rerum commodi commodi qui ea.', '', 6, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(15, 'Nesciunt soluta exercitationem mollitia aliquam.', '', 8, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(16, 'Neque a sint sunt quo dolorem et accusantium eligendi.', '', 16, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(17, 'Amet est dolores ut dolorem repellat ipsum commodi.', '', 4, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(18, 'Suscipit voluptas accusantium ea culpa aperiam libero omnis.', '', 4, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(19, 'Iusto ratione asperiores autem.', '', 16, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(20, 'Est non et eos eos ex.', '', 9, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(21, 'Rerum qui quia voluptas accusantium at labore.', '', 17, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(22, 'Aliquam placeat labore laboriosam non adipisci.', '', 3, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(23, 'Cupiditate voluptatem odio id est itaque esse ut.', '', 12, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(24, 'Reprehenderit cum dolorem aspernatur magnam qui.', '', 7, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(25, 'Voluptatum pariatur molestiae sit voluptas eius hic molestiae.', '', 14, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(26, 'Labore sit quos ea ad voluptas minus.', '', 19, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(27, 'Ipsam labore dignissimos ea voluptas labore quod eius et.', '', 7, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(28, 'Molestias asperiores molestias autem voluptas.', '', 20, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(29, 'Reiciendis veritatis tenetur ducimus.', '', 9, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(30, 'Illo laboriosam praesentium a vel id non.', '', 15, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(31, 'Est tempora ut fuga repudiandae.', '', 15, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(32, 'Voluptas omnis aut nobis sit.', '', 17, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(33, 'At velit dolor culpa aut placeat libero.', '', 14, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(34, 'Eos aspernatur impedit repellendus dolore et.', '', 19, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(35, 'Sit nemo sunt quo sit.', '', 16, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(36, 'Reiciendis fugiat modi quaerat illum ratione.', '', 3, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(37, 'Ut exercitationem et sit.', '', 2, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(38, 'Ullam ut sed porro ipsam id ut.', '', 6, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(39, 'Modi pariatur assumenda molestiae omnis voluptates.', '', 1, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(40, 'Cum rem veniam voluptatum at provident.', '', 15, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(41, 'Repellendus fugit animi id illum omnis ea.', '', 8, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(42, 'Et eos repellendus est non.', '', 16, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(43, 'Expedita vero commodi dolorum.', '', 20, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(44, 'Sit itaque architecto ipsum assumenda reprehenderit rem cum.', '', 6, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(45, 'Unde dolor temporibus eos hic et voluptatem.', '', 1, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(46, 'Non mollitia commodi quo qui non.', '', 5, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(47, 'Praesentium corporis est quod et.', '', 4, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(48, 'Voluptas ut quae dicta earum autem dolores.', '', 8, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(49, 'Nobis ut repellat enim natus.', '', 7, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(50, 'Dolores et qui nulla inventore exercitationem dolores velit.', '', 7, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(51, 'Dicta cum voluptatem velit.', '', 2, 0, 0, '2015-08-06 04:07:07', '2015-08-06 04:07:07'),
(52, 'Eligendi est ea aut et optio.', '', 5, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(53, 'Aut quas voluptate vel molestiae ut aut.', '', 14, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(54, 'Quis facilis culpa dicta sed quam dolore quidem.', '', 8, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(55, 'Dolore accusantium est necessitatibus sunt officiis consectetur sunt.', '', 3, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(56, 'Cumque omnis quis libero enim sequi earum consequatur.', '', 17, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(57, 'Ex incidunt quam maiores beatae repudiandae aliquam ad.', '', 4, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(58, 'Quisquam nihil ut distinctio.', '', 17, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(59, 'Sapiente voluptatem ut a sed.', '', 3, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(60, 'Delectus vitae aliquam repellendus expedita eum deserunt a.', '', 17, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(61, 'Voluptas suscipit laborum facilis nostrum sit quam veniam quisquam.', '', 1, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(62, 'Sint veritatis earum ut excepturi magni.', '', 4, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(63, 'Fuga consequatur rem aut.', '', 19, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(64, 'Aut commodi nostrum nobis autem voluptatem.', '', 13, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(65, 'Enim magnam recusandae dolore.', '', 4, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(66, 'Saepe et rerum nostrum placeat et et temporibus.', '', 17, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(67, 'Ipsam a sequi distinctio eaque.', '', 12, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(68, 'In id quas unde explicabo.', '', 1, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(69, 'Molestiae qui nulla qui expedita nesciunt accusantium.', '', 4, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(70, 'Vel alias iste culpa sint.', '', 17, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(71, 'Dignissimos placeat et quo.', '', 5, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(72, 'Sequi et consequatur provident at qui suscipit eos dolor.', '', 3, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(73, 'Est et ipsam animi porro saepe.', '', 8, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(74, 'Facere odit aut sint esse vero voluptatem.', '', 13, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(75, 'Nostrum sit minima dolor cum pariatur rerum sapiente.', '', 19, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(76, 'Nisi et a voluptatibus harum tempore facere perspiciatis id.', '', 15, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(77, 'Illum eaque iure ut et aspernatur et.', '', 2, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(78, 'Ea aperiam consequuntur ex in quo totam ut.', '', 9, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(79, 'Voluptas culpa illo totam.', '', 10, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(80, 'Repellat sequi aliquam iure possimus cum aperiam.', '', 7, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(81, 'Sunt libero in in.', '', 16, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(82, 'Dolores sint dignissimos commodi ratione laboriosam quos et.', '', 15, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(83, 'Excepturi qui eveniet non eos dolorum.', '', 11, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(84, 'Quibusdam et dolor non non similique.', '', 1, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(85, 'Minima et placeat a quis.', '', 8, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(86, 'Fugit eius aliquam quo perferendis dolor vero consequuntur.', '', 20, 0, 0, '2015-08-06 04:07:08', '2015-08-06 04:07:08'),
(87, 'Aperiam necessitatibus soluta dignissimos dolores ducimus in eos.', '', 3, 0, 0, '2015-08-06 04:07:09', '2015-08-06 04:07:09'),
(88, 'Officia voluptas labore consequuntur doloremque iusto.', '', 9, 0, 0, '2015-08-06 04:07:09', '2015-08-06 04:07:09'),
(89, 'Deleniti sed veritatis et accusamus rerum distinctio soluta.', '', 4, 0, 0, '2015-08-06 04:07:09', '2015-08-06 04:07:09'),
(90, 'Voluptatem laboriosam fugiat quo quia.', '', 19, 0, 0, '2015-08-06 04:07:09', '2015-08-06 04:07:09'),
(91, 'Temporibus harum ut est sunt.', '', 3, 0, 0, '2015-08-06 04:07:09', '2015-08-06 04:07:09'),
(92, 'Quibusdam voluptatem exercitationem omnis blanditiis.', '', 8, 0, 0, '2015-08-06 04:07:09', '2015-08-06 04:07:09'),
(93, 'Rerum exercitationem quia et vitae blanditiis.', '', 15, 0, 0, '2015-08-06 04:07:09', '2015-08-06 04:07:09'),
(94, 'Dolore voluptatem nihil dolor velit tempora labore eos.', '', 2, 0, 0, '2015-08-06 04:07:09', '2015-08-06 04:07:09'),
(95, 'Voluptatibus voluptas qui iste reiciendis.', '', 6, 0, 0, '2015-08-06 04:07:09', '2015-08-06 04:07:09'),
(96, 'Illo fugit ut dolorem est cumque.', '', 5, 0, 0, '2015-08-06 04:07:09', '2015-08-06 04:07:09'),
(97, 'Doloremque repudiandae impedit nobis quisquam voluptatem quisquam.', '', 15, 0, 0, '2015-08-06 04:07:09', '2015-08-06 04:07:09'),
(98, 'Est ut earum debitis voluptatibus nulla enim aspernatur.', '', 2, 0, 0, '2015-08-06 04:07:09', '2015-08-06 04:07:09'),
(99, 'Et totam voluptate sunt odio est laboriosam.', '', 18, 0, 0, '2015-08-06 04:07:09', '2015-08-06 04:07:09'),
(100, 'Deserunt est praesentium voluptas molestiae praesentium.', '', 11, 0, 0, '2015-08-06 04:07:09', '2015-08-06 04:07:09');

-- --------------------------------------------------------

--
-- Table structure for table `message_organization`
--

CREATE TABLE IF NOT EXISTS `message_organization` (
  `message_id` int(10) unsigned NOT NULL,
  `organization_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2015_06_02_051614_create_organizations_table', 1),
('2015_06_02_055651_entrust_setup_tables', 1),
('2015_06_02_090139_create_activities_table', 1),
('2015_06_02_093826_create_tasks_table', 1),
('2015_06_04_082317_user_organization', 1),
('2015_06_07_053108_create_litigations_table', 1),
('2015_06_07_054326_create_shelter_homes_table', 1),
('2015_06_07_061520_add_description_and_address_fields_to_litigations', 1),
('2015_06_07_095408_add_created_by_to_litigations', 1),
('2015_06_08_081727_change_litigation_victom_birth_date_to_date_from_datetime', 1),
('2015_06_08_105420_create_care_plans_table', 1),
('2015_06_08_123226_create_service_managements_table', 1),
('2015_06_09_062111_pivotal_table_for_shelter_home_and_care_plan', 1),
('2015_06_11_065629_create_task_statuses_table', 1),
('2015_06_11_090153_add_shelter_home_id_to_litigation', 1),
('2015_06_14_084127_create_pivotal_for_care_palns_litigation', 1),
('2015_06_14_115719_case_profile', 1),
('2015_06_15_114355_remove_previous_next_from_tasks_table', 1),
('2015_06_15_115329_create_task_to_task_table', 1),
('2015_06_21_075429_create_revisions_table', 1),
('2015_06_22_180717_create_tweets_table', 1),
('2015_06_23_050152_add_avatar_fields_to_tweets_table', 1),
('2015_06_24_111400_add_status_field_to_care_plan_litigation_pivotal', 1),
('2015_06_29_060836_add_image_fields_to_litigations_table', 1),
('2015_06_30_061229_create_attachments_table', 1),
('2015_06_30_065112_remove_image_fields_from_litigations_table', 1),
('2015_07_01_063805_create_attachment_litigation_table', 1),
('2015_07_01_063905_create_doc_types_table', 1),
('2015_07_01_063937_create_user_defined_doc_types_table', 1),
('2015_07_06_124849_create_case_dashboard_table', 1),
('2015_07_12_114357_add_assign_to_field_in_litigation_task_task_status', 1),
('2015_07_13_175430_create_messages_table', 1),
('2015_07_21_115530_message_organization', 1),
('2015_07_22_163112_create_litigation_organization_table', 1),
('2015_07_23_112409_add_organization_id_to_user_table', 1),
('2015_07_26_144948_remove_assigned_no_from_litigation_task_task_status_add_assigned_country', 2),
('2015_07_29_124643_add_default_countries_to_tasks', 3),
('2015_08_02_103243_add_destination_country_to_litigation', 4);

-- --------------------------------------------------------

--
-- Table structure for table `organizations`
--

CREATE TABLE IF NOT EXISTS `organizations` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `address` text COLLATE utf8_unicode_ci NOT NULL,
  `country` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `organizations`
--

INSERT INTO `organizations` (`id`, `name`, `description`, `address`, `country`, `created_at`, `updated_at`) VALUES
(1, 'DNET', 'asdf', 'asdf', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'NGO Kolkata', 'Quis mollitia qui animi delectus sint maxime corrupti labore adipisci labore quibusdam ad quas similique hic autem voluptas voluptatem', 'Odit aut nemo non ex exercitationem aliquid', '2', '2015-07-23 09:37:28', '2015-07-23 09:37:28'),
(3, 'NGO Delhi', 'Quia ut odio aspernatur est suscipit enim do quia iure debitis et eius cumque aut exercitationem', 'Veritatis proident repellendus Architecto id minima consequatur Dolorem eos magni', '2', '2015-07-23 09:46:33', '2015-07-23 09:46:33'),
(4, 'NGO Jessore', '', 'Nemo inventore consequuntur commodi harum enim rerum assumenda ea in amet laboriosam sit qui cillum laboriosam tenetur voluptate sequi nobis', '1', '2015-07-23 09:46:54', '2015-07-23 09:46:54'),
(5, 'NGO Dhaka', '', 'Irure ut quaerat tempor est voluptate sit nulla nostrum id mollitia qui fugit fuga', '1', '2015-07-23 09:47:10', '2015-07-23 09:47:10'),
(6, 'NGO Nepal', 'Maxime aute aliquam quia ut ut corrupti laboriosam voluptate sed fugit quos deleniti consectetur', 'Aute occaecat placeat aliqua Illum eveniet assumenda iste hic', '3', '2015-07-23 09:49:27', '2015-07-23 09:49:27'),
(7, 'NGO Mumbai', '', 'asdf', '2', '2015-07-23 10:11:06', '2015-07-23 10:11:06'),
(8, 'no user ngo', '', 'dhaka', '1', '2015-08-02 08:48:25', '2015-08-02 08:48:25'),
(9, 'no user ngo nepal', '', 'asdf', '3', '2015-08-03 04:54:54', '2015-08-03 04:54:54');

-- --------------------------------------------------------

--
-- Table structure for table `organization_user`
--

CREATE TABLE IF NOT EXISTS `organization_user` (
  `organization_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `organization_user`
--

INSERT INTO `organization_user` (`organization_id`, `user_id`) VALUES
(1, 1),
(2, 7),
(4, 9);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE IF NOT EXISTS `permission_role` (
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `revisions`
--

CREATE TABLE IF NOT EXISTS `revisions` (
  `id` int(10) unsigned NOT NULL,
  `revisionable_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `revisionable_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `old_value` text COLLATE utf8_unicode_ci,
  `new_value` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `revisions`
--

INSERT INTO `revisions` (`id`, `revisionable_type`, `revisionable_id`, `user_id`, `key`, `old_value`, `new_value`, `created_at`, `updated_at`) VALUES
(1, 'App\\Litigation', 1, 7, 'Creation', '', '', '2015-07-23 10:13:58', '2015-07-23 10:13:58'),
(2, 'App\\Litigation', 4, 8, 'Creation', '', '', '2015-07-23 11:04:15', '2015-07-23 11:04:15'),
(3, 'App\\Litigation', 5, 7, 'Creation', '', '', '2015-07-23 11:45:12', '2015-07-23 11:45:12'),
(4, 'App\\Litigation', 7, 8, 'Creation', '', '', '2015-07-23 11:49:05', '2015-07-23 11:49:05'),
(5, 'App\\Litigation', 10, 1, 'Creation', '', '', '2015-07-23 12:01:19', '2015-07-23 12:01:19'),
(6, 'App\\Litigation', 5, 7, 'dob', '0000-00-00', '1901-01-15', '2015-07-26 06:38:27', '2015-07-26 06:38:27'),
(7, 'App\\Litigation', 1, 7, 'dob', '0000-00-00', '1993-02-09', '2015-07-26 06:38:49', '2015-07-26 06:38:49'),
(8, 'App\\Litigation', 10, 1, 'Care Planes', '', '', '2015-07-26 12:18:49', '2015-07-26 12:18:49'),
(9, 'App\\Litigation', 14, 1, 'Creation', '', '', '2015-07-29 08:30:35', '2015-07-29 08:30:35'),
(10, 'App\\Litigation', 15, 1, 'Creation', '', '', '2015-07-29 08:30:44', '2015-07-29 08:30:44'),
(11, 'App\\Litigation', 16, 1, 'Creation', '', '', '2015-07-29 08:31:10', '2015-07-29 08:31:10'),
(12, 'App\\Litigation', 17, 1, 'Creation', '', '', '2015-07-29 08:31:24', '2015-07-29 08:31:24'),
(13, 'App\\Litigation', 18, 1, 'Creation', '', '', '2015-07-29 08:32:28', '2015-07-29 08:32:28'),
(14, 'App\\Litigation', 19, 1, 'Creation', '', '', '2015-07-29 08:32:31', '2015-07-29 08:32:31'),
(15, 'App\\Litigation', 20, 1, 'Creation', '', '', '2015-07-29 08:32:55', '2015-07-29 08:32:55'),
(16, 'App\\Litigation', 21, 1, 'Creation', '', '', '2015-07-29 08:33:10', '2015-07-29 08:33:10'),
(17, 'App\\Litigation', 22, 1, 'Creation', '', '', '2015-07-29 08:37:31', '2015-07-29 08:37:31'),
(18, 'App\\Litigation', 23, 1, 'Creation', '', '', '2015-07-29 08:38:04', '2015-07-29 08:38:04'),
(19, 'App\\Litigation', 24, 1, 'Creation', '', '', '2015-07-29 08:39:01', '2015-07-29 08:39:01'),
(21, 'App\\Litigation', 26, 1, 'Creation', '', '', '2015-07-29 08:42:23', '2015-07-29 08:42:23'),
(22, 'App\\Litigation', 27, 1, 'Creation', '', '', '2015-07-29 08:50:07', '2015-07-29 08:50:07'),
(23, 'App\\Litigation', 28, 1, 'Creation', '', '', '2015-08-02 05:10:17', '2015-08-02 05:10:17'),
(24, 'App\\Litigation', 27, 1, 'Task Status', '', 'Skip for task Intake', '2015-08-02 12:23:12', '2015-08-02 12:23:12'),
(25, 'App\\Litigation', 27, 1, 'Task Status', 'Skip for task Intake', 'Skip for task FIR', '2015-08-02 12:23:15', '2015-08-02 12:23:15'),
(26, 'App\\Litigation', 27, 1, 'Task Status', 'Skip for task FIR', 'New for task FIR', '2015-08-02 12:23:16', '2015-08-02 12:23:16'),
(27, 'App\\Litigation', 27, 1, 'Task Status', 'New for task FIR', 'Complete for task CWC', '2015-08-02 12:23:18', '2015-08-02 12:23:18'),
(28, 'App\\Litigation', 6, 1, 'country_of_origin', '1', '2', '2015-08-03 04:43:21', '2015-08-03 04:43:21'),
(29, 'App\\Litigation', 6, 1, 'destination_country', '2', NULL, '2015-08-03 04:43:21', '2015-08-03 04:43:21'),
(30, 'App\\Litigation', 6, 1, 'destination_country', '0', NULL, '2015-08-03 04:44:44', '2015-08-03 04:44:44'),
(31, 'App\\Litigation', 6, 1, 'destination_country', '0', NULL, '2015-08-03 04:49:10', '2015-08-03 04:49:10'),
(32, 'App\\Litigation', 6, 1, 'country_of_origin', '2', '1', '2015-08-03 04:50:12', '2015-08-03 04:50:12'),
(33, 'App\\Litigation', 6, 1, 'destination_country', '0', '2', '2015-08-03 04:50:12', '2015-08-03 04:50:12'),
(34, 'App\\Litigation', 6, 1, 'country_of_origin', '1', '3', '2015-08-03 05:10:56', '2015-08-03 05:10:56'),
(35, 'App\\Litigation', 6, 1, 'age', '11', '112', '2015-08-03 05:18:11', '2015-08-03 05:18:11'),
(36, 'App\\Litigation', 1, 1, 'Task Status', '', 'Complete for task CWC', '2015-08-03 09:04:38', '2015-08-03 09:04:38'),
(37, 'App\\Litigation', 1, 1, 'Task Status', 'Complete for task CWC', 'New for task CWC', '2015-08-03 09:04:40', '2015-08-03 09:04:40'),
(38, 'App\\Litigation', 1, 1, 'Task Status', 'New for task CWC', 'Skip for task CWC', '2015-08-03 09:04:41', '2015-08-03 09:04:41'),
(39, 'App\\Litigation', 1, 1, 'Task Status', 'Skip for task CWC', 'Skip for task Counselling Report', '2015-08-03 09:19:01', '2015-08-03 09:19:01'),
(40, 'App\\Litigation', 1, 1, 'Task Status', 'Skip for task Counselling Report', 'Complete for task Counselling Report', '2015-08-03 09:19:05', '2015-08-03 09:19:05'),
(41, 'App\\Litigation', 1, 1, 'Task Status', 'Complete for task Counselling Report', 'In Progress for task Counselling Report', '2015-08-03 09:19:11', '2015-08-03 09:19:11'),
(42, 'App\\Litigation', 1, 1, 'Task Status', 'In Progress for task Counselling Report', 'New for task Intake', '2015-08-03 09:19:16', '2015-08-03 09:19:16'),
(43, 'App\\Litigation', 1, 1, 'Task Status', 'New for task Intake', 'New for task CWC', '2015-08-03 09:19:18', '2015-08-03 09:19:18'),
(44, 'App\\Litigation', 1, 1, 'Task Status', 'New for task CWC', 'Skip for task CWC', '2015-08-03 09:19:21', '2015-08-03 09:19:21'),
(45, 'App\\Litigation', 1, 1, 'Task Status', 'Skip for task CWC', 'New for task Counselling Report', '2015-08-03 09:19:51', '2015-08-03 09:19:51'),
(46, 'App\\Litigation', 1, 1, 'Task Status', 'New for task Counselling Report', 'Skip for task Counselling Report', '2015-08-03 09:19:55', '2015-08-03 09:19:55'),
(47, 'App\\Litigation', 1, 1, 'Task Status', 'Skip for task Counselling Report', 'Skip for task Repatriation', '2015-08-03 09:20:02', '2015-08-03 09:20:02'),
(48, 'App\\Litigation', 1, 1, 'Task Status', 'Skip for task Repatriation', 'New for task Escort and Handover', '2015-08-03 09:20:05', '2015-08-03 09:20:05'),
(49, 'App\\Litigation', 1, 1, 'Task Status', 'New for task Escort and Handover', 'Complete for task Fixing Repatriation Date', '2015-08-03 09:20:08', '2015-08-03 09:20:08'),
(50, 'App\\Litigation', 1, 1, 'Task Status', 'Complete for task Fixing Repatriation Date', 'In Progress for task Fixing Repatriation Date', '2015-08-03 09:20:12', '2015-08-03 09:20:12'),
(51, 'App\\Litigation', 1, 1, 'Task Status', 'In Progress for task Fixing Repatriation Date', 'New for task Issue of NOC', '2015-08-03 09:20:16', '2015-08-03 09:20:16'),
(52, 'App\\Litigation', 1, 1, 'Task Status', 'New for task Issue of NOC', 'New for task Repatriation Order', '2015-08-03 09:20:41', '2015-08-03 09:20:41'),
(53, 'App\\Litigation', 1, 1, 'Task Status', 'New for task Repatriation Order', 'New for task Repatriation', '2015-08-03 09:20:45', '2015-08-03 09:20:45'),
(54, 'App\\Litigation', 1, 1, 'Task Status', 'New for task Repatriation', 'Complete for task State HIR', '2015-08-03 09:37:51', '2015-08-03 09:37:51'),
(55, 'App\\Litigation', 1, 1, 'Task Status', 'Complete for task State HIR', 'Complete for task State HIR', '2015-08-03 09:37:54', '2015-08-03 09:37:54'),
(56, 'App\\Litigation', 1, 1, 'Task Status', 'Complete for task State HIR', 'Complete for task State HIR', '2015-08-03 09:38:35', '2015-08-03 09:38:35'),
(57, 'App\\Litigation', 1, 1, 'Task Status', 'Complete for task State HIR', 'Complete for task Repatriation', '2015-08-03 09:39:31', '2015-08-03 09:39:31'),
(58, 'App\\Litigation', 1, 1, 'Task Status', 'Complete for task Repatriation', 'In Progress for task Repatriation', '2015-08-03 09:39:34', '2015-08-03 09:39:34'),
(59, 'App\\Litigation', 4, 1, 'Task Status', '', 'Skip for task Intake', '2015-08-03 09:39:55', '2015-08-03 09:39:55'),
(60, 'App\\Litigation', 4, 1, 'Task Status', 'Skip for task Intake', 'New for task Escort and Handover', '2015-08-03 09:39:59', '2015-08-03 09:39:59'),
(61, 'App\\Litigation', 4, 1, 'Task Status', 'New for task Escort and Handover', 'New for task Issue of NOC', '2015-08-03 11:52:14', '2015-08-03 11:52:14'),
(62, 'App\\Litigation', 4, 1, 'Task Status', 'New for task Issue of NOC', 'New for task Intake', '2015-08-03 12:06:40', '2015-08-03 12:06:40'),
(63, 'App\\Litigation', 4, 1, 'Task Status', 'New for task Intake', 'In Progress for task Intake', '2015-08-03 12:06:41', '2015-08-03 12:06:41'),
(64, 'App\\Litigation', 4, 1, 'Task Status', 'In Progress for task Intake', 'In Progress for task Mag. Court Order', '2015-08-03 12:30:39', '2015-08-03 12:30:39'),
(65, 'App\\Litigation', 4, 1, 'Task Status', 'In Progress for task Mag. Court Order', 'New for task Intake', '2015-08-04 05:29:08', '2015-08-04 05:29:08'),
(66, 'App\\Litigation', 4, 1, 'Task Status', 'New for task Intake', 'New for task FIR', '2015-08-04 05:39:18', '2015-08-04 05:39:18'),
(67, 'App\\Litigation', 4, 1, 'Task Status', 'New for task FIR', 'New for task FIR', '2015-08-04 05:39:40', '2015-08-04 05:39:40'),
(68, 'App\\Litigation', 4, 1, 'Task Status', 'New for task FIR', 'Skip for task FIR', '2015-08-04 05:45:38', '2015-08-04 05:45:38'),
(69, 'App\\Litigation', 4, 1, 'Task Status', 'Skip for task FIR', 'Complete for task FIR', '2015-08-04 05:45:40', '2015-08-04 05:45:40'),
(70, 'App\\Litigation', 4, 1, 'Task Status', 'Complete for task FIR', 'New for task FIR', '2015-08-04 05:45:42', '2015-08-04 05:45:42'),
(71, 'App\\Litigation', 4, 1, 'Task Status', 'New for task FIR', 'In Progress for task Intake', '2015-08-04 05:46:32', '2015-08-04 05:46:32'),
(72, 'App\\Litigation', 10, 1, 'Task Status', '', 'Complete for task FIR', '2015-08-04 06:26:22', '2015-08-04 06:26:22'),
(73, 'App\\Litigation', 10, 1, 'Task Status', 'Complete for task FIR', 'Skip for task CWC', '2015-08-04 06:26:24', '2015-08-04 06:26:24'),
(74, 'App\\Litigation', 10, 1, 'Task Status', 'Skip for task CWC', 'In Progress for task FIR', '2015-08-04 06:26:25', '2015-08-04 06:26:25'),
(75, 'App\\Litigation', 10, 1, 'Task Status', 'In Progress for task FIR', 'New for task FIR', '2015-08-04 06:26:26', '2015-08-04 06:26:26'),
(76, 'App\\Litigation', 27, 7, 'Task Status', 'Complete for task CWC', 'In Progress for task Intake', '2015-08-04 08:31:58', '2015-08-04 08:31:58'),
(77, 'App\\Litigation', 27, 7, 'Task Status', 'In Progress for task Intake', 'Complete for task Repatriation', '2015-08-04 08:32:00', '2015-08-04 08:32:00'),
(78, 'App\\Litigation', 27, 7, 'Task Status', 'Complete for task Repatriation', 'In Progress for task Repatriation', '2015-08-04 08:32:01', '2015-08-04 08:32:01'),
(79, 'App\\Litigation', 10, 1, 'Task Status', 'New for task FIR', 'Complete for task FIR', '2015-08-04 08:32:10', '2015-08-04 08:32:10'),
(80, 'App\\Litigation', 10, 1, 'Task Status', 'Complete for task FIR', 'In Progress for task CWC', '2015-08-04 08:32:12', '2015-08-04 08:32:12'),
(81, 'App\\Litigation', 10, 1, 'Task Status', 'In Progress for task CWC', 'Skip for task Fixing Repatriation Date', '2015-08-04 08:35:42', '2015-08-04 08:35:42'),
(82, 'App\\Litigation', 10, 1, 'Task Status', 'Skip for task Fixing Repatriation Date', 'Complete for task Repatriation', '2015-08-04 08:35:47', '2015-08-04 08:35:47'),
(83, 'App\\Litigation', 10, 1, 'Task Status', 'Complete for task Repatriation', 'Complete for task Issue of NOC', '2015-08-04 08:43:12', '2015-08-04 08:43:12'),
(84, 'App\\Litigation', 10, 1, 'Task Status', 'Complete for task Issue of NOC', 'New for task FIR', '2015-08-04 08:43:36', '2015-08-04 08:43:36'),
(85, 'App\\Litigation', 10, 1, 'Task Status', 'New for task FIR', 'Complete for task Repatriation Order', '2015-08-04 08:45:10', '2015-08-04 08:45:10'),
(86, 'App\\Litigation', 10, 1, 'Task Status', 'Complete for task Repatriation Order', 'Skip for task Medical Report', '2015-08-04 08:46:01', '2015-08-04 08:46:01'),
(87, 'App\\Litigation', 10, 1, 'Task Status', 'Skip for task Medical Report', 'Skip for task Counselling Report', '2015-08-04 08:46:22', '2015-08-04 08:46:22'),
(88, 'App\\Litigation', 27, 7, 'Task Status', 'In Progress for task Repatriation', 'Complete for task Repatriation', '2015-08-04 08:46:26', '2015-08-04 08:46:26'),
(89, 'App\\Litigation', 27, 7, 'Task Status', 'Complete for task Repatriation', 'Skip for task Repatriation', '2015-08-04 08:46:54', '2015-08-04 08:46:54'),
(90, 'App\\Litigation', 27, 7, 'Task Status', 'Skip for task Repatriation', 'New for task Repatriation', '2015-08-04 08:48:38', '2015-08-04 08:48:38'),
(91, 'App\\Litigation', 27, 7, 'Task Status', 'New for task Repatriation', 'Complete for task Intake', '2015-08-04 08:48:41', '2015-08-04 08:48:41'),
(92, 'App\\Litigation', 27, 7, 'Task Status', 'Complete for task Intake', 'Skip for task Repatriation', '2015-08-04 08:48:43', '2015-08-04 08:48:43'),
(93, 'App\\Litigation', 10, 1, 'Task Status', 'Skip for task Counselling Report', 'Complete for task State HIR', '2015-08-04 09:23:54', '2015-08-04 09:23:54'),
(94, 'App\\Litigation', 10, 1, 'victim_name', 'Orli Wilkinson', 'Orli Wilkinson hello', '2015-08-13 06:18:55', '2015-08-13 06:18:55'),
(95, 'App\\Litigation', 10, 1, 'country_of_origin', '0', '1', '2015-08-13 06:18:55', '2015-08-13 06:18:55');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'owner', 'Project Owner', 'User is the owner of a given project', '2015-05-24 04:33:59', '2015-05-24 04:33:59'),
(2, 'admin', 'Administrator', 'User is allowed to manage and add/edit Models', '2015-05-24 04:38:37', '2015-05-24 04:38:37'),
(3, 'contributor', 'Contributor', 'This user is the case manager', '2015-05-24 04:44:51', '2015-05-24 04:44:51');

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE IF NOT EXISTS `role_user` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`user_id`, `role_id`) VALUES
(1, 1),
(3, 2),
(4, 3),
(5, 3),
(6, 3),
(7, 3),
(8, 3),
(9, 3),
(10, 3),
(11, 3),
(12, 3),
(14, 3),
(15, 3),
(16, 3);

-- --------------------------------------------------------

--
-- Table structure for table `service_managements`
--

CREATE TABLE IF NOT EXISTS `service_managements` (
  `id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shelter_homes`
--

CREATE TABLE IF NOT EXISTS `shelter_homes` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `capacity` int(11) NOT NULL,
  `services` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE IF NOT EXISTS `tasks` (
  `id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activity_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `countries` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `title`, `activity_id`, `countries`, `created_at`, `updated_at`) VALUES
(2, 'Intake', '1', '1', '2015-07-23 11:00:35', '2015-07-23 11:00:35'),
(3, 'FIR', '1', '1', '2015-07-23 11:00:35', '2015-07-23 11:00:35'),
(4, 'CWC', '1', '1', '2015-07-23 11:00:35', '2015-07-23 11:00:35'),
(5, 'Mag. Court Order', '1', '1', '2015-07-23 11:00:35', '2015-07-23 11:00:35'),
(6, 'Counselling Report', '1', '1', '2015-07-23 11:00:35', '2015-07-23 11:00:35'),
(7, 'Medical Report', '1', '1', '2015-07-23 11:00:35', '2015-07-23 11:00:35'),
(8, 'P. O. Report', '1', '1', '2015-07-23 11:00:35', '2015-07-23 11:00:35'),
(9, 'Nationality Identification', '4', '1', '2015-07-23 11:00:35', '2015-07-23 11:00:35'),
(10, 'NGO HIR', '4', '1', '2015-07-23 11:00:35', '2015-07-23 11:00:35'),
(11, 'State HIR', '4', '1', '2015-07-23 11:00:35', '2015-07-23 11:00:35'),
(12, 'Repatriation Order', '4', '1', '2015-07-23 11:00:35', '2015-07-23 11:00:35'),
(13, 'Issue of NOC', '4', '1', '2015-07-23 11:00:35', '2015-07-23 11:00:35'),
(14, 'Fixing Repatriation Date', '4', '1', '2015-07-23 11:00:35', '2015-07-23 11:00:35'),
(15, 'Escort and Handover', '4', '1', '2015-07-23 11:00:35', '2015-07-29 07:48:32'),
(16, 'Repatriation', '1', '1', '2015-07-23 11:00:35', '2015-07-23 11:00:35');

-- --------------------------------------------------------

--
-- Table structure for table `task_statuses`
--

CREATE TABLE IF NOT EXISTS `task_statuses` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `task_statuses`
--

INSERT INTO `task_statuses` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'New', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'In Progress', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'Skip', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'Complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `task_to_task`
--

CREATE TABLE IF NOT EXISTS `task_to_task` (
  `from_task` int(11) NOT NULL,
  `to_task` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `task_to_task`
--

INSERT INTO `task_to_task` (`from_task`, `to_task`) VALUES
(2, 3),
(3, 4),
(4, 5),
(5, 6),
(6, 7),
(7, 8);

-- --------------------------------------------------------

--
-- Table structure for table `tweets`
--

CREATE TABLE IF NOT EXISTS `tweets` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sku` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avatar_file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avatar_file_size` int(11) DEFAULT NULL,
  `avatar_content_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avatar_updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `organization_id` int(11) NOT NULL DEFAULT '1',
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `organization_id`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'The Developer', 'bazlur.rashid@dnet.org.bd', 1, '$2y$10$/Ya3OwGnkdHtd6MairoNROZwxTkcFrEqJv7CpW1YntefDtmuzVT8G', 'Nl9BhbHvxUjgTsHf03WHVAwaOpnXvIfgVhAutpblcw2G6k4jveSGxw86kzWa', '2015-05-20 05:00:30', '2015-08-12 21:58:20'),
(3, 'The Site Admin', 'sakib.sharif@dnet.org.bd', 1, '$2y$10$/Ya3OwGnkdHtd6MairoNROZwxTkcFrEqJv7CpW1YntefDtmuzVT8G', '', '2015-05-24 04:40:57', '2015-05-24 04:48:23'),
(4, 'MCA', 'assdfsdfsd@aaa.com', 1, '$2y$10$ayD00VUbERm6fA6RZ1WNpun1Tcm5gorA0IXw6rbGOfTQc0Vj/iANq', NULL, '2015-06-01 04:20:53', '2015-06-01 04:20:53'),
(5, 'bazlur', 'mailtobazlur5@gmail.com', 1, '$2y$10$kyeuwryATFSBwdLAMgmII.ty7oDpXGJkY3GSSfVC4808NecOi4iZK', NULL, '2015-06-01 22:31:29', '2015-06-01 22:31:29'),
(6, 'sdfsd', 'mailtobazlur24@gmail.com', 1, '$2y$10$Q6tgeI6vopK8dV.xmJ.6Heavxif7Z/imH3MNCaVXcC2E6yTdndRt.', NULL, '2015-06-01 23:02:24', '2015-06-01 23:02:24'),
(7, 'ngo kolkata', 'ngokolkata@mcaconnect.org', 2, '$2y$10$1HgDl7uzsLqCENgjREEJyeAf559xa0RkTUaSw.Tk3PqU9PpgToyDS', 'YgNx75R3FVh5Mw6NOTbzP8q77OgImgDkmFJWxP3wveMNXAjLNA7zeyCrpvad', '2015-07-23 10:00:11', '2015-08-16 04:20:19'),
(8, 'ngo delhi', 'ngodelhi@mcaconnect.org', 3, '$2y$10$6Cte844CqfqhnjaqpJP0yOzyp0i19YxcRrLn7NVCsfzUbR4CcJS.e', 'KSFT6SfrvdkiH5HhXoUPQtb1nOJKSpIX6uAkz2F9U8Obwb9iIY2Z62VN5fgx', '2015-07-23 10:01:12', '2015-08-03 07:46:56'),
(9, 'ngo jessore', 'ngojessore@mcaconnect.org', 4, '$2y$10$eNVbdOl5ts2BWPx5p89mpekEZtwXNG/FZ6tcDY/KJI/vKa.WKu9.C', '09X3dpnntjZS93wccr1UQVBXf5TTZ30DdSp80AGPPuQdtwJZgi4BU63BlUGI', '2015-07-23 10:01:55', '2015-08-04 04:36:49'),
(10, 'ngo dhaka', 'ngodhaka@mcaconnect.org', 5, '$2y$10$1c2X7Zpr9MUjQ096CUsm8OqZ51q/NxiVMlls5lnf7wrh.EVpeAaDW', 'HtikMyQKpwaOX6ZhJwUwjpQcZajRqIDSrAAFG4s8yEaIo52w5QxOlvl3m6h6', '2015-07-23 10:03:54', '2015-08-02 08:49:15'),
(11, 'ngo mumbai', 'ngomumbai@mcaconnect.org', 7, '$2y$10$6E4uGGdYatPP.TlJcpzsl.odpFZFbIjqVJj5HsOonrbbyLe9zc4Pe', 'Tz6ZbO2YxERRvbUobJgTdJULp2hEMVfIlfaQsRTvL0OaWO1SO35JR1f4byTl', '2015-07-23 10:11:35', '2015-08-03 08:50:29'),
(12, 'ngonepal', 'ngonepal@mcaconnect.org', 6, '$2y$10$4zdMLWu2Uy3cb5q8A/apkuoh6G3dSyN4IPono2/YMacjg3xt1Jttu', 'oFOwNnclNcA9j5Z6IvFxfhSpjHs7nE3BgEd5hVHo9J3kl2Sr3cTfMzE3IvX6', '2015-07-29 12:18:40', '2015-07-29 12:20:21'),
(14, 'no user ngo?', 'nouserngo@mcaconnect.org', 1, '$2y$10$7p8WtFyjLocyvBbOwHrv6emQfGFiKTN64Foh77lquNSkJ6S43DReu', 'hpdwYovBRXuzcSbEgta1Jgf6XuofiqlN85zqtcEwRjBKT3uHDrXjfBdVHNlt', '2015-08-02 09:49:20', '2015-08-02 10:39:14'),
(15, 'no user ngo 2', 'nouserngo2@mcaconnect.org', 1, '$2y$10$noF2LgGQbrKLzKXUiE7XLusfnPJ4xhau0/aySWwA6MnhnIN1Giihi', NULL, '2015-08-02 10:17:00', '2015-08-02 10:17:00'),
(16, 'nouserngonepal', 'nouserngonepal@mcaconnect.org', 9, '$2y$10$R4dHOYYrpeT0ixh3kUZhduwM9lorPmyQV4eSICPlwqvMSTVj/aApa', NULL, '2015-08-03 04:55:37', '2015-08-03 04:55:37');

-- --------------------------------------------------------

--
-- Table structure for table `user_defined_doc_types`
--

CREATE TABLE IF NOT EXISTS `user_defined_doc_types` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `is_revised` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attachments`
--
ALTER TABLE `attachments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attachment_litigation`
--
ALTER TABLE `attachment_litigation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `care_plans`
--
ALTER TABLE `care_plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `care_plan_litigation`
--
ALTER TABLE `care_plan_litigation`
  ADD PRIMARY KEY (`litigation_id`,`care_plan_id`),
  ADD KEY `care_plan_litigation_care_plan_id_foreign` (`care_plan_id`);

--
-- Indexes for table `care_plan_shelter_home`
--
ALTER TABLE `care_plan_shelter_home`
  ADD PRIMARY KEY (`shelter_home_id`,`care_plan_id`),
  ADD KEY `care_plan_shelter_home_care_plan_id_foreign` (`care_plan_id`);

--
-- Indexes for table `case_profiles`
--
ALTER TABLE `case_profiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doc_types`
--
ALTER TABLE `doc_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `litigations`
--
ALTER TABLE `litigations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `litigation_organization`
--
ALTER TABLE `litigation_organization`
  ADD PRIMARY KEY (`litigation_id`,`organization_id`),
  ADD KEY `litigation_organization_organization_id_foreign` (`organization_id`);

--
-- Indexes for table `litigation_task_task_status`
--
ALTER TABLE `litigation_task_task_status`
  ADD PRIMARY KEY (`litigation_id`,`task_id`,`assigned_country`),
  ADD KEY `litigation_task_task_status_task_id_foreign` (`task_id`),
  ADD KEY `litigation_task_task_status_task_status_id_foreign` (`task_status_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message_organization`
--
ALTER TABLE `message_organization`
  ADD PRIMARY KEY (`organization_id`,`message_id`);

--
-- Indexes for table `organizations`
--
ALTER TABLE `organizations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `organization_user`
--
ALTER TABLE `organization_user`
  ADD PRIMARY KEY (`user_id`,`organization_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_unique` (`name`);

--
-- Indexes for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `permission_role_role_id_foreign` (`role_id`);

--
-- Indexes for table `revisions`
--
ALTER TABLE `revisions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `revisions_revisionable_id_revisionable_type_index` (`revisionable_id`,`revisionable_type`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`user_id`,`role_id`),
  ADD KEY `role_user_role_id_foreign` (`role_id`);

--
-- Indexes for table `service_managements`
--
ALTER TABLE `service_managements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shelter_homes`
--
ALTER TABLE `shelter_homes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `task_statuses`
--
ALTER TABLE `task_statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tweets`
--
ALTER TABLE `tweets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_defined_doc_types`
--
ALTER TABLE `user_defined_doc_types`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `attachments`
--
ALTER TABLE `attachments`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `attachment_litigation`
--
ALTER TABLE `attachment_litigation`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `care_plans`
--
ALTER TABLE `care_plans`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `case_profiles`
--
ALTER TABLE `case_profiles`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `doc_types`
--
ALTER TABLE `doc_types`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `litigations`
--
ALTER TABLE `litigations`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=101;
--
-- AUTO_INCREMENT for table `organizations`
--
ALTER TABLE `organizations`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `revisions`
--
ALTER TABLE `revisions`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=96;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `service_managements`
--
ALTER TABLE `service_managements`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `shelter_homes`
--
ALTER TABLE `shelter_homes`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `task_statuses`
--
ALTER TABLE `task_statuses`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tweets`
--
ALTER TABLE `tweets`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `user_defined_doc_types`
--
ALTER TABLE `user_defined_doc_types`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `care_plan_litigation`
--
ALTER TABLE `care_plan_litigation`
  ADD CONSTRAINT `care_plan_litigation_care_plan_id_foreign` FOREIGN KEY (`care_plan_id`) REFERENCES `care_plans` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `care_plan_litigation_litigation_id_foreign` FOREIGN KEY (`litigation_id`) REFERENCES `litigations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `care_plan_shelter_home`
--
ALTER TABLE `care_plan_shelter_home`
  ADD CONSTRAINT `care_plan_shelter_home_care_plan_id_foreign` FOREIGN KEY (`care_plan_id`) REFERENCES `care_plans` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `care_plan_shelter_home_shelter_home_id_foreign` FOREIGN KEY (`shelter_home_id`) REFERENCES `shelter_homes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `litigation_organization`
--
ALTER TABLE `litigation_organization`
  ADD CONSTRAINT `litigation_organization_litigation_id_foreign` FOREIGN KEY (`litigation_id`) REFERENCES `litigations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `litigation_organization_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `litigation_task_task_status`
--
ALTER TABLE `litigation_task_task_status`
  ADD CONSTRAINT `litigation_task_task_status_litigation_id_foreign` FOREIGN KEY (`litigation_id`) REFERENCES `litigations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `litigation_task_task_status_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `litigation_task_task_status_task_status_id_foreign` FOREIGN KEY (`task_status_id`) REFERENCES `task_statuses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
