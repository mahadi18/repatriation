-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 12, 2016 at 11:20 AM
-- Server version: 5.5.46-0ubuntu0.14.04.2
-- PHP Version: 5.5.9-1ubuntu4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mcaapp_production`
--

-- --------------------------------------------------------

--
-- Table structure for table `forms`
--

CREATE TABLE IF NOT EXISTS `forms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `order` int(11) NOT NULL,
  `country_id` int(11) DEFAULT '1',
  `generic` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=37 ;

--
-- Dumping data for table `forms`
--

INSERT INTO `forms` (`id`, `task_id`, `title`, `created_at`, `updated_at`, `order`, `country_id`, `generic`) VALUES
(1, 10, 'NGO BD apply for Repatriation to MoHA', '2015-09-27 08:31:07', '2016-06-29 04:37:19', 10, 1, 1),
(3, 10, 'SBHQ sends home verification report to MoHA', '2015-09-27 08:53:16', '2016-05-18 22:10:34', 20, 1, 1),
(11, 11, 'Request for FRRO Clearance from BDHC/ NGO IN to Home F&NRI/ I Branch', '2015-09-27 09:03:52', '2015-11-18 03:06:30', 10, 1, 1),
(12, 11, 'Request for NOC Letter from F&NRI to IG IB', '2015-09-27 09:04:13', '2015-11-18 03:08:38', 20, 1, 1),
(13, 11, 'Request for NOC Letter from Home F&NRI/ I Branch or IG IB to DIB/ Local Police', '2015-09-27 09:07:15', '2015-11-18 03:09:00', 30, 1, 1),
(14, 11, 'Request for NOC from NGO IN to DWCD/ MHA Maharashtra (Required for Maharashtra only)', '2015-09-27 09:07:41', '2016-05-18 22:10:57', 50, 1, 1),
(15, 11, 'DIB/ Local Police Send NOC to Home F&NRI/ I Branch', '2015-09-27 09:08:17', '2015-11-18 03:09:22', 40, 1, 1),
(16, 13, 'MoHA Issue and Send Repatriation Order to MoFA', '2015-09-27 09:09:27', '2015-11-18 03:15:56', 10, 1, 1),
(17, 13, 'NGO BD forward Repatriation Order to NGO IN', '2015-09-27 09:09:42', '2015-11-18 03:16:07', 20, 1, 1),
(18, 13, 'NGO IN forward RO to BDHC, CWC/ Magistrate Court', '2015-09-27 09:10:00', '2015-11-18 03:16:36', 30, 1, 1),
(20, 15, 'Fixation of Repatriation Date', '2015-09-27 09:11:27', '2015-11-18 03:19:12', 10, 1, 1),
(21, 15, 'Survivor Handover', '2015-09-27 09:11:40', '2015-11-18 00:08:58', 20, 1, 1),
(22, 16, 'Home F&NRI/ I Branch Issue and Send Repatriation Letter to DIB/ NGO IN', '2015-11-03 22:17:47', '2015-11-18 03:17:27', 10, 1, 1),
(23, 17, 'BDHC Issue Travel Permit', '2015-11-17 05:53:23', '2015-11-17 05:59:08', 10, 1, 1),
(24, 10, 'MoHA sends State HIR request to SBHQ', '2015-11-18 02:34:21', '2015-11-18 02:34:21', 15, 1, 1),
(25, 11, 'MHA Maharashtra Issue and Send NOC to NGO IN (Required for Maharashtra only)', '2015-11-18 03:10:40', '2016-05-18 22:11:15', 60, 1, 1),
(26, 16, 'NGO IN Forward Repatriation Letter to NGO BD', '2015-11-18 03:17:46', '2015-11-18 03:17:46', 20, 1, 1),
(27, 11, 'Form for nepal', '2016-06-29 03:57:08', '2016-06-29 05:56:43', 10, 3, 0),
(28, 11, 'Form for nepal 2', '2016-06-29 03:57:37', '2016-06-30 00:41:58', 30, 3, 0),
(32, 15, 'Fixation of Repatriation Date', '2016-07-12 03:37:29', '2016-07-12 04:54:45', 10, 3, 0),
(33, 15, 'Survivor Handover', '2016-07-12 03:42:14', '2016-07-12 04:54:48', 20, 3, 0),
(34, 16, 'NGO India submit HIR document to CWC/ Magistrate Court', '2016-07-13 02:50:42', '2016-07-13 03:21:10', 10, 3, 0),
(35, 16, 'CWC/ Magistrate Court issue CRD (Case Release Document)', '2016-07-13 03:16:39', '2016-07-13 03:21:14', 20, 3, 0),
(36, 16, 'NGO India forwards CRD to Consulate, Nepal Embassy', '2016-07-13 03:18:52', '2016-07-13 03:46:21', 30, 3, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
